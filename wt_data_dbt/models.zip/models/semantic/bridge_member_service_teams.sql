{{ config(materialized='table') }}

SELECT DISTINCT
    member_id,
    svc_team
FROM {{ ref('stg_fs_members_patched') }}
CROSS JOIN UNNEST(svc_teams) AS svc_team
WHERE svc_team IS NOT NULL
