{{ config(materialized='table') }}

WITH service_summary AS (

    SELECT
        roster_id,
        COUNT(*) AS service_count,
        MIN(service_start_at) AS first_service_start_at,
        MAX(service_end_at) AS last_service_end_at
    FROM {{ ref('int_roster_service_datetimes') }}
    GROUP BY roster_id

),

rehearsal_summary AS (

    SELECT
        roster_id,
        COUNT(*) AS rehearsal_count,
        MIN(rehearsal_start_at) AS first_rehearsal_start_at,
        MAX(rehearsal_end_at) AS last_rehearsal_end_at
    FROM {{ ref('int_roster_rehearsal_datetimes') }}
    GROUP BY roster_id

),

assignment_summary AS (

    SELECT
        roster_id,
        COUNT(DISTINCT member_id) AS assigned_member_count,
        COUNT(DISTINCT role) AS assigned_role_count,
        COUNT(*) AS assignment_count
    FROM {{ ref('int_roster_assigned_members_roles') }}
    GROUP BY roster_id

)

SELECT
    r.roster_id,
    r.chat_title,
    r.description_text,
    r.notes_text,
    r.status,
    r.svc_team,
    r.first_svc_date,
    r.telegram_chat_id,
    COALESCE(s.service_count, 0) AS service_count,
    s.first_service_start_at,
    s.last_service_end_at,
    COALESCE(reh.rehearsal_count, 0) AS rehearsal_count,
    reh.first_rehearsal_start_at,
    reh.last_rehearsal_end_at,
    COALESCE(a.assigned_member_count, 0) AS assigned_member_count,
    COALESCE(a.assigned_role_count, 0) AS assigned_role_count,
    COALESCE(a.assignment_count, 0) AS assignment_count,
    r.source_created_at,
    r.source_updated_at,
    r.ingested_at,
    r.batch_id
FROM {{ ref('stg_fs_rosters') }} AS r
LEFT JOIN service_summary AS s
    ON r.roster_id = s.roster_id
LEFT JOIN rehearsal_summary AS reh
    ON r.roster_id = reh.roster_id
LEFT JOIN assignment_summary AS a
    ON r.roster_id = a.roster_id
