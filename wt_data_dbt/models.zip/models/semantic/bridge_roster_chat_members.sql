{{ config(materialized='table') }}

SELECT DISTINCT
    roster_id,
    chat_member_id
FROM {{ ref('int_roster_chat_members') }}
WHERE chat_member_id IS NOT NULL
